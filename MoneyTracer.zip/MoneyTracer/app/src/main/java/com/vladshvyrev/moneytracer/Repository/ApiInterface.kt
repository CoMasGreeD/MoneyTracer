package com.vladshvyrev.moneytracer.Repository

interface ApiInterface {
}