package com.vladshvyrev.moneytracer.ui.fragments.CreateNewTransaction

class CreateNewTransactionViewModel {
}