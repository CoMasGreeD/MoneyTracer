package com.vladshvyrev.moneytracer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toolbar

import com.vladshvyrev.moneytracer.ui.fragments.MainPage.MainPageFragment
import com.vladshvyrev.moneytracer.ui.fragments.PinCodeSqreen.PinCodeSqreenFragment


class MainActivity : AppCompatActivity() {

    private var toolbar : Toolbar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar = findViewById(R.id.my_Toolbar)

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container,PinCodeSqreenFragment())
            .commit()


    }
    fun startMainPageFragment()
    {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, MainPageFragment())
            .commit()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.mainmenu,menu)
        return true
    }
}


