package com.vladshvyrev.moneytracer.Repository

interface Repository {
}