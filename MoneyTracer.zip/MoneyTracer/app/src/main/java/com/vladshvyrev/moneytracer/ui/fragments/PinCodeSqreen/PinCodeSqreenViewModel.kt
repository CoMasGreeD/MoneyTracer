package com.vladshvyrev.moneytracer.ui.fragments.PinCodeSqreen

class PinCodeSqreenViewModel {
}