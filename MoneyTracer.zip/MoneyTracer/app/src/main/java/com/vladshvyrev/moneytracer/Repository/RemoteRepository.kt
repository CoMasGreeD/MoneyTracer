package com.vladshvyrev.moneytracer.Repository

class RemoteRepository {
}